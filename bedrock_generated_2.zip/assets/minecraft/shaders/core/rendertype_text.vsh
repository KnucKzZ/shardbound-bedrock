#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a5cd02b2(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_a4876507() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_01b1e2c8(inout vec4 vertex) {
    f_a5cd02b2(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_a4876507();
    }
    finalize();
}



void f_837cd113() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_9142fdb6() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_d25c9dd2(inout vec4 vertex) {
    f_a5cd02b2(vertex);
    f_837cd113();
    finalize();
}

void f_062aefef(inout vec4 vertex) {
    f_a5cd02b2(vertex);
    f_a4876507();
    f_9142fdb6();
    finalize();
}

void f_f7e742ed(inout vec4 vertex) {
    f_a5cd02b2(vertex);
    f_9142fdb6();
    f_837cd113();
    finalize();
}

void f_178ee4b0(inout vec4 vertex) {
    f_a4876507();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a5cd02b2(vertex);
    finalize();
}

void f_d40960ff(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_837cd113();
    f_a5cd02b2(vertex);
    finalize();
}

void f_7b2dcde7(inout vec4 vertex, float speed) {
    f_a5cd02b2(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_5335b98e(inout vec4 vertex) {
    f_a5cd02b2(vertex);
    f_a4876507();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_01b1e2c8(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_a4876507();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a5cd02b2(vertex);
            f_a4876507();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_062aefef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_062aefef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_178ee4b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_178ee4b0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_7b2dcde7(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_5335b98e(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_d25c9dd2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_062aefef(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_f7e742ed(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_178ee4b0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_d40960ff(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_7b2dcde7(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_d25c9dd2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_062aefef(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_f7e742ed(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_178ee4b0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_d40960ff(vertex);
        return;
    }
    

    
    f_a5cd02b2(vertex);
    f_a4876507();
    finalize();
}