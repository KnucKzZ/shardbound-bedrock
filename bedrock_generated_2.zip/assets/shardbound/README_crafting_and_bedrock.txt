Shardbound ItemsAdder Build Packs - Crafting Notes

Included build packs with crafting enabled for normal players:
- furnituresplusfree
- gardenplus
- itemshopplus

Important:
1) Many of these packs already include ItemsAdder crafting_table recipes.
2) Recipe permission gates were removed from these build packs so default players can craft them.
3) Bedrock players can craft them too, but Bedrock usually will NOT show custom ItemsAdder recipes inside the vanilla recipe book. They must either:
   - know the pattern,
   - use a guide/menu, or
   - get recipes shown through your server docs/guide NPC.

Recommended server commands after installing:
/iazip
/iareload

Useful admin commands:
/ia
/ia recipes
/iagive <player> <namespace:item>

If you want full survival progression, make a recipe guide for players or a custom menu/NPC that lists the main furniture recipes.
