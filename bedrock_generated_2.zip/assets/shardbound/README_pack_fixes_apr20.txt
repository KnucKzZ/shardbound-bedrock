Applied fixes:
- gardenplus hanging plant recipes: CHAIN -> IRON_BARS for ItemsAdder 4.0.16 compatibility.
- removed invalid duplicate texture filename: cyansummer - Copie.png
- added placeholder misc textures required by itemshopplus sellbox model so pack generation stays clean.
